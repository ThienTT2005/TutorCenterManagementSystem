create
    definer = root@localhost procedure sp_generate_sessions_from_schedule(IN p_class_id int, IN p_start_date date, IN p_end_date date)
BEGIN
    DECLARE v_current_date DATE;
    DECLARE v_weekday INT;
    DECLARE v_schedule_weekday INT;
    DECLARE v_start_time TIME;
    DECLARE v_end_time TIME;
    DECLARE done INT DEFAULT FALSE;

    DECLARE cur CURSOR FOR
        SELECT weekday, start_time, end_time
        FROM teaching_schedules
        WHERE class_id = p_class_id;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    SET v_current_date = p_start_date;

    WHILE v_current_date <= p_end_date DO
            SET v_weekday = DAYOFWEEK(v_current_date);

            OPEN cur;
            read_loop: LOOP
                FETCH cur INTO v_schedule_weekday, v_start_time, v_end_time;
                IF done THEN
                    SET done = FALSE;
                    LEAVE read_loop;
                END IF;

                IF v_weekday = v_schedule_weekday THEN
                    IF NOT EXISTS (
                        SELECT 1 FROM teaching_sessions
                        WHERE class_id = p_class_id AND session_date = v_current_date
                    ) THEN
                        INSERT INTO teaching_sessions (class_id, session_date, start_time, end_time, status)
                        VALUES (p_class_id, v_current_date, v_start_time, v_end_time, 'PLANNED');
                    END IF;
                END IF;
            END LOOP;
            CLOSE cur;

            SET v_current_date = DATE_ADD(v_current_date, INTERVAL 1 DAY);
        END WHILE;
END;

