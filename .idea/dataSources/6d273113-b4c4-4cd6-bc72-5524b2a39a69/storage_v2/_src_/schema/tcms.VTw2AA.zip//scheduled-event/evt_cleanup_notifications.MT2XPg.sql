create definer = root@localhost event evt_cleanup_notifications on schedule
    every '1' DAY
        starts '2026-05-11 02:00:00'
    enable
    do
    CALL sp_cleanup_old_notifications();

