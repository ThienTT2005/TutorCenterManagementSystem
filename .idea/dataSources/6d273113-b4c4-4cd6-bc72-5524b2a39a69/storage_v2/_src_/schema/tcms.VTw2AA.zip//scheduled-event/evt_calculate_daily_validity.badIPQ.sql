create definer = root@localhost event evt_calculate_daily_validity on schedule
    every '1' DAY
        starts '2026-05-11 23:00:00'
    enable
    do
    CALL sp_calculate_all_classes_validity();

