create definer = root@localhost event evt_send_upcoming_session_notifications on schedule
    every '1' HOUR
        starts '2026-05-10 00:50:46'
    enable
    do
    CALL sp_send_upcoming_session_notifications();

