create definer = root@localhost trigger trg_notification_on_feedback
    after insert
    on feedback
    for each row
BEGIN
    DECLARE v_user_id INT;
    DECLARE v_student_name VARCHAR(100);
    DECLARE v_session_date DATE;
    DECLARE v_parent_user_id INT;

    SELECT s.full_name, ses.session_date, s.user_id
    INTO v_student_name, v_session_date, v_user_id
    FROM students s
             JOIN teaching_sessions ses ON ses.session_id = NEW.session_id
    WHERE s.student_id = NEW.student_id;

    SELECT u.user_id INTO v_parent_user_id
    FROM parents p
             JOIN users u ON p.user_id = u.user_id
    WHERE p.parent_id = (SELECT parent_id FROM students WHERE student_id = NEW.student_id);

    IF v_parent_user_id IS NOT NULL THEN
        INSERT INTO notifications (user_id, title, content, type, reference_id, reference_table)
        VALUES (v_parent_user_id,
                'Feedback mới',
                CONCAT('Học sinh ', v_student_name, ' đã có feedback cho buổi học ngày ', v_session_date),
                'FEEDBACK',
                NEW.feedback_id,
                'feedback');
    END IF;

    INSERT INTO notifications (user_id, title, content, type, reference_id, reference_table)
    VALUES (v_user_id,
            'Feedback mới',
            CONCAT('Bạn đã có feedback cho buổi học ngày ', v_session_date),
            'FEEDBACK',
            NEW.feedback_id,
            'feedback');
END;

