create
    definer = root@localhost procedure sp_calculate_all_classes_validity()
BEGIN
    DECLARE v_class_id INT;
    DECLARE done INT DEFAULT FALSE;

    DECLARE cur CURSOR FOR SELECT class_id FROM classes WHERE status = TRUE;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_class_id;
        IF done THEN
            LEAVE read_loop;
        END IF;
        CALL sp_calculate_class_validity(v_class_id);
    END LOOP;
    CLOSE cur;
END;

