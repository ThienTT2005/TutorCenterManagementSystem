create definer = root@localhost trigger trg_notification_on_payment_request
    after insert
    on payments
    for each row
BEGIN
    DECLARE v_parent_user_id INT;
    DECLARE v_admin_user_id INT;
    DECLARE v_class_name VARCHAR(100);

    SELECT u.user_id, c.class_name
    INTO v_parent_user_id, v_class_name
    FROM students s
             JOIN parents p ON s.parent_id = p.parent_id
             JOIN users u ON p.user_id = u.user_id
             JOIN classes c ON NEW.class_id = c.class_id
    WHERE s.student_id = NEW.student_id;

    SELECT user_id INTO v_admin_user_id
    FROM users
    WHERE role_id = 1 LIMIT 1;

    IF v_parent_user_id IS NOT NULL THEN
        INSERT INTO notifications (user_id, title, content, type, reference_id, reference_table)
        VALUES (v_parent_user_id,
                'Yêu cầu thanh toán mới',
                CONCAT('Lớp ', v_class_name, ' có yêu cầu thanh toán số tiền ', FORMAT(NEW.amount, 0), ' VNĐ'),
                'PAYMENT',
                NEW.payment_id,
                'payments');
    END IF;

    IF v_admin_user_id IS NOT NULL THEN
        INSERT INTO notifications (user_id, title, content, type, reference_id, reference_table)
        VALUES (v_admin_user_id,
                'Yêu cầu thanh toán cần duyệt',
                CONCAT('Lớp ', v_class_name, ' - Số tiền: ', FORMAT(NEW.amount, 0), ' VNĐ'),
                'PAYMENT',
                NEW.payment_id,
                'payments');
    END IF;
END;

