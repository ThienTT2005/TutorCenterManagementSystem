create definer = root@localhost view vw_class_session_stats as
select `c`.`class_id`                                                  AS `class_id`,
       `c`.`class_name`                                                AS `class_name`,
       `c`.`subject`                                                   AS `subject`,
       `t`.`full_name`                                                 AS `tutor_name`,
       count(`s`.`session_id`)                                         AS `total_sessions`,
       sum((case when (`s`.`status` = 'COMPLETED') then 1 else 0 end)) AS `completed_sessions`,
       sum((case when (`s`.`status` = 'CANCELLED') then 1 else 0 end)) AS `cancelled_sessions`,
       sum((case when (`s`.`status` = 'PLANNED') then 1 else 0 end))   AS `planned_sessions`
from ((`tcms`.`classes` `c` left join `tcms`.`tutors` `t`
       on ((`c`.`tutor_id` = `t`.`tutor_id`))) left join `tcms`.`teaching_sessions` `s`
      on ((`c`.`class_id` = `s`.`class_id`)))
group by `c`.`class_id`, `c`.`class_name`, `c`.`subject`, `t`.`full_name`;

