create
    definer = root@localhost procedure sp_calculate_session_validity(IN p_session_id int, IN p_student_id int)
BEGIN
    DECLARE v_attendance_valid BOOLEAN DEFAULT FALSE;
    DECLARE v_feedback_penalty DECIMAL(5,2) DEFAULT 0;
    DECLARE v_feedback_status VARCHAR(20);
    DECLARE v_calculated_amount DECIMAL(10,2);
    DECLARE v_tuition_fee DECIMAL(10,2);

    SELECT c.tuition_fee_per_session INTO v_tuition_fee
    FROM teaching_sessions s
             JOIN classes c ON s.class_id = c.class_id
    WHERE s.session_id = p_session_id;

    SELECT is_valid INTO v_attendance_valid
    FROM attendance
    WHERE session_id = p_session_id AND student_id = p_student_id;

    SELECT penalty_rate, IF(is_late = TRUE, 'LATE', 'ON_TIME')
    INTO v_feedback_penalty, v_feedback_status
    FROM feedback
    WHERE session_id = p_session_id AND student_id = p_student_id AND status = 'APPROVED';

    IF v_attendance_valid = TRUE AND v_feedback_status IS NOT NULL THEN
        SET v_calculated_amount = v_tuition_fee * (100 - v_feedback_penalty) / 100;
    ELSE
        SET v_calculated_amount = 0;
    END IF;

    INSERT INTO session_validity_log (session_id, student_id, attendance_valid,
                                      feedback_status, feedback_penalty, calculated_amount)
    VALUES (p_session_id, p_student_id, v_attendance_valid,
            v_feedback_status, v_feedback_penalty, v_calculated_amount)
    ON DUPLICATE KEY UPDATE
                         attendance_valid = v_attendance_valid,
                         feedback_status = v_feedback_status,
                         feedback_penalty = v_feedback_penalty,
                         calculated_amount = v_calculated_amount,
                         calculated_at = CURRENT_TIMESTAMP;
END;

