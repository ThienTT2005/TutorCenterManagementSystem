create definer = root@localhost trigger trg_generate_attendance_code
    before insert
    on teaching_sessions
    for each row
BEGIN
    IF NEW.attendance_code IS NULL OR NEW.attendance_code = '' THEN
        SET NEW.attendance_code = LPAD(FLOOR(RAND() * 1000000), 6, '0');
    END IF;
END;

