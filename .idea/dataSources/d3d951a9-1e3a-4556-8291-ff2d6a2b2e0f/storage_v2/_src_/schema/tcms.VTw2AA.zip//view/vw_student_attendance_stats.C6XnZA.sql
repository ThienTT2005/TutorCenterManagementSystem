create definer = root@localhost view vw_student_attendance_stats as
select `s`.`student_id`                                                                              AS `student_id`,
       `s`.`full_name`                                                                               AS `full_name`,
       count(`a`.`attendance_id`)                                                                    AS `total_sessions`,
       sum((case
                when ((`a`.`status` = 'ATTENDED') and (`a`.`is_valid` = true)) then 1
                else 0 end))                                                                         AS `attended_valid`,
       sum((case
                when ((`a`.`status` = 'ATTENDED') and (`a`.`is_valid` = false)) then 1
                else 0 end))                                                                         AS `attended_invalid`,
       sum((case when (`a`.`status` = 'ABSENT_EXCUSED') then 1 else 0 end))                          AS `absent_excused`,
       sum((case when (`a`.`status` = 'ABSENT_UNEXCUSED') then 1 else 0 end))                        AS `absent_unexcused`,
       round(((sum((case when ((`a`.`status` = 'ATTENDED') and (`a`.`is_valid` = true)) then 1 else 0 end)) * 100.0) /
              nullif(count(`a`.`attendance_id`), 0)),
             2)                                                                                      AS `attendance_rate`
from (`tcms`.`students` `s` left join `tcms`.`attendance` `a` on ((`s`.`student_id` = `a`.`student_id`)))
group by `s`.`student_id`, `s`.`full_name`;

