create
    definer = root@localhost procedure sp_tutor_dashboard(IN p_tutor_id int)
BEGIN
    SELECT COUNT(DISTINCT s.session_id) AS classes_today
    FROM teaching_sessions s
             JOIN classes c ON s.class_id = c.class_id
    WHERE c.tutor_id = p_tutor_id
      AND s.session_date = CURDATE()
      AND s.status IN ('PLANNED', 'ONGOING');

    SELECT COUNT(DISTINCT f.feedback_id) AS pending_feedback
    FROM feedback f
             JOIN teaching_sessions s ON f.session_id = s.session_id
             JOIN classes c ON s.class_id = c.class_id
    WHERE c.tutor_id = p_tutor_id
      AND f.status = 'PENDING';

    SELECT COUNT(DISTINCT hs.submission_id) AS homework_to_grade
    FROM homework_submissions hs
             JOIN homework h ON hs.homework_id = h.homework_id
             JOIN teaching_sessions s ON h.session_id = s.session_id
             JOIN classes c ON s.class_id = c.class_id
    WHERE c.tutor_id = p_tutor_id
      AND hs.status = 'SUBMITTED';

    SELECT COUNT(*) AS pending_payments
    FROM payments
    WHERE tutor_id = p_tutor_id
      AND status IN ('PENDING', 'PROOF_UPLOADED');
END;

