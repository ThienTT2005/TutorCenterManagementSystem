create definer = root@localhost view vw_payment_stats as
select `c`.`class_id`          AS `class_id`,
       `c`.`class_name`        AS `class_name`,
       `p`.`status`            AS `status`,
       count(`p`.`payment_id`) AS `payment_count`,
       sum(`p`.`amount`)       AS `total_amount`,
       avg(`p`.`amount`)       AS `avg_amount`
from (`tcms`.`classes` `c` left join `tcms`.`payments` `p` on ((`c`.`class_id` = `p`.`class_id`)))
group by `c`.`class_id`, `c`.`class_name`, `p`.`status`;

