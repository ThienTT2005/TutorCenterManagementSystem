create definer = root@localhost trigger trg_notification_on_homework
    after insert
    on homework
    for each row
BEGIN
    DECLARE v_class_id INT;
    DECLARE v_student_id INT;
    DECLARE v_student_user_id INT;
    DECLARE v_student_name VARCHAR(100);
    DECLARE v_parent_user_id INT;
    DECLARE done INT DEFAULT FALSE;

    DECLARE cur CURSOR FOR
        SELECT DISTINCT s.student_id, s.user_id, s.full_name, pu.user_id as parent_user_id
        FROM enrollments e
                 JOIN students s ON e.student_id = s.student_id
                 LEFT JOIN parents p ON s.parent_id = p.parent_id
                 LEFT JOIN users pu ON p.user_id = pu.user_id
        WHERE e.class_id = (SELECT class_id FROM teaching_sessions WHERE session_id = NEW.session_id);

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_student_id, v_student_user_id, v_student_name, v_parent_user_id;
        IF done THEN
            LEAVE read_loop;
        END IF;

        INSERT INTO notifications (user_id, title, content, type, reference_id, reference_table)
        VALUES (v_student_user_id,
                'Bài tập về nhà mới',
                CONCAT('Bạn có bài tập mới: ', NEW.title, ' - Hạn nộp: ', NEW.deadline),
                'HOMEWORK',
                NEW.homework_id,
                'homework');

        IF v_parent_user_id IS NOT NULL THEN
            INSERT INTO notifications (user_id, title, content, type, reference_id, reference_table)
            VALUES (v_parent_user_id,
                    'Bài tập về nhà mới cho con',
                    CONCAT('Con bạn ', v_student_name, ' có bài tập mới: ', NEW.title, ' - Hạn nộp: ', NEW.deadline),
                    'HOMEWORK',
                    NEW.homework_id,
                    'homework');
        END IF;
    END LOOP;
    CLOSE cur;
END;

