create definer = root@localhost trigger trg_payment_status_timestamps
    before update
    on payments
    for each row
BEGIN
    IF NEW.status = 'PROOF_UPLOADED' AND OLD.status != 'PROOF_UPLOADED' THEN
        SET NEW.request_date = NOW();
    END IF;

    IF NEW.status = 'TUTOR_CONFIRMED' AND OLD.status != 'TUTOR_CONFIRMED' THEN
        SET NEW.tutor_confirmed_at = NOW();
    END IF;

    IF NEW.status IN ('ADMIN_APPROVED', 'COMPLETED') AND OLD.status NOT IN ('ADMIN_APPROVED', 'COMPLETED') THEN
        SET NEW.admin_approved_at = NOW();
    END IF;
END;

