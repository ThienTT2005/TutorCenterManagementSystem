create
    definer = root@localhost procedure sp_student_dashboard(IN p_student_id int)
BEGIN
    SELECT COUNT(DISTINCT s.session_id) AS classes_today
    FROM teaching_sessions s
             JOIN classes c ON s.class_id = c.class_id
             JOIN enrollments e ON c.class_id = e.class_id
    WHERE e.student_id = p_student_id
      AND s.session_date = CURDATE();

    SELECT COUNT(DISTINCT h.homework_id) AS homework_pending
    FROM homework h
             JOIN teaching_sessions s ON h.session_id = s.session_id
             JOIN classes c ON s.class_id = c.class_id
             JOIN enrollments e ON c.class_id = e.class_id
             LEFT JOIN homework_submissions hs ON h.homework_id = hs.homework_id AND hs.student_id = p_student_id
    WHERE e.student_id = p_student_id
      AND (hs.submission_id IS NULL OR hs.status = 'SUBMITTED' AND hs.graded_at IS NULL)
      AND h.deadline >= CURDATE();

    SELECT COUNT(*) AS new_feedback
    FROM feedback
    WHERE student_id = p_student_id
      AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY);
END;

