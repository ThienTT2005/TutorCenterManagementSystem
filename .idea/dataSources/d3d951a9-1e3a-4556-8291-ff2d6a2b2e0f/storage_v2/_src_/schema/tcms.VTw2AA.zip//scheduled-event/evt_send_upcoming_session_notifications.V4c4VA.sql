create definer = root@localhost event evt_send_upcoming_session_notifications on schedule
    every '1' HOUR
        starts '2026-06-14 23:35:08'
    enable
    do
    CALL sp_send_upcoming_session_notifications();

