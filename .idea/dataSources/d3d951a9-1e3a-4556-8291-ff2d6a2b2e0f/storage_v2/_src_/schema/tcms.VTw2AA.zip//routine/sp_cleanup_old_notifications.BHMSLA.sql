create
    definer = root@localhost procedure sp_cleanup_old_notifications()
BEGIN
    DELETE FROM notifications
    WHERE is_read = TRUE
      AND read_at < DATE_SUB(NOW(), INTERVAL 1 DAY);

    DELETE FROM notifications
    WHERE is_read = FALSE
      AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);

    DELETE FROM notifications
    WHERE expires_at IS NOT NULL
      AND expires_at < NOW();
END;

