create
    definer = root@localhost procedure sp_calculate_class_validity(IN p_class_id int)
BEGIN
    DECLARE v_session_id INT;
    DECLARE v_student_id INT;
    DECLARE done INT DEFAULT FALSE;

    DECLARE cur CURSOR FOR
        SELECT DISTINCT s.session_id, e.student_id
        FROM teaching_sessions s
                 JOIN enrollments e ON s.class_id = e.class_id
        WHERE s.class_id = p_class_id AND s.status = 'COMPLETED';

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_session_id, v_student_id;
        IF done THEN
            LEAVE read_loop;
        END IF;

        CALL sp_calculate_session_validity(v_session_id, v_student_id);
    END LOOP;
    CLOSE cur;
END;

