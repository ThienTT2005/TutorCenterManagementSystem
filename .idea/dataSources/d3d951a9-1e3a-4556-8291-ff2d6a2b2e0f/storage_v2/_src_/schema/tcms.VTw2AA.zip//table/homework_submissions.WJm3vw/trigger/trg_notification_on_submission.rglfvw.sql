create definer = root@localhost trigger trg_notification_on_submission
    after insert
    on homework_submissions
    for each row
BEGIN
    DECLARE v_tutor_user_id INT;
    DECLARE v_homework_title VARCHAR(255);
    DECLARE v_student_name VARCHAR(100);

    SELECT t.user_id, h.title, s.full_name
    INTO v_tutor_user_id, v_homework_title, v_student_name
    FROM homework h
             JOIN teaching_sessions ses ON h.session_id = ses.session_id
             JOIN classes c ON ses.class_id = c.class_id
             JOIN tutors t ON c.tutor_id = t.tutor_id
             JOIN students s ON NEW.student_id = s.student_id
    WHERE h.homework_id = NEW.homework_id;

    INSERT INTO notifications (user_id, title, content, type, reference_id, reference_table)
    VALUES (v_tutor_user_id,
            'Bài tập mới được nộp',
            CONCAT('Học sinh ', v_student_name, ' đã nộp bài tập "', v_homework_title, '"'),
            'HOMEWORK',
            NEW.submission_id,
            'homework_submissions');
END;

