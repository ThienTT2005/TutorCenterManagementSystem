create definer = root@localhost trigger trg_calculate_attendance_validity
    before update
    on attendance
    for each row
BEGIN
    DECLARE v_scheduled_start DATETIME;
    DECLARE v_scheduled_end DATETIME;
    DECLARE v_checkin_diff INT;
    DECLARE v_checkout_diff INT;

    IF NEW.checkin_time IS NOT NULL AND NEW.checkout_time IS NOT NULL THEN
        SELECT CONCAT(s.session_date, ' ', s.start_time),
               CONCAT(s.session_date, ' ', s.end_time)
        INTO v_scheduled_start, v_scheduled_end
        FROM teaching_sessions s
        WHERE s.session_id = NEW.session_id;

        SET v_checkin_diff = ABS(TIMESTAMPDIFF(MINUTE, v_scheduled_start, NEW.checkin_time));
        SET v_checkout_diff = ABS(TIMESTAMPDIFF(MINUTE, v_scheduled_end, NEW.checkout_time));

        IF v_checkin_diff <= 15 AND v_checkout_diff <= 15 AND NEW.status = 'ATTENDED' THEN
            SET NEW.is_valid = TRUE;
        ELSE
            SET NEW.is_valid = FALSE;
        END IF;
    END IF;
END;

