create
    definer = root@localhost procedure sp_send_upcoming_session_notifications()
BEGIN
    DECLARE v_session_id INT;
    DECLARE v_class_id INT;
    DECLARE v_session_date DATE;
    DECLARE v_start_time TIME;
    DECLARE v_tutor_user_id INT;
    DECLARE done INT DEFAULT FALSE;

    DECLARE cur_sessions CURSOR FOR
        SELECT s.session_id, s.class_id, s.session_date, s.start_time
        FROM teaching_sessions s
        WHERE s.session_date = CURDATE()
          AND s.start_time BETWEEN CURTIME() AND ADDTIME(CURTIME(), '02:00:00')
          AND s.status = 'PLANNED';

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur_sessions;
    read_loop: LOOP
        FETCH cur_sessions INTO v_session_id, v_class_id, v_session_date, v_start_time;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Thông báo cho tutor
        SELECT u.user_id INTO v_tutor_user_id
        FROM tutors t
                 JOIN users u ON t.user_id = u.user_id
                 JOIN classes c ON t.tutor_id = c.tutor_id
        WHERE c.class_id = v_class_id;

        IF v_tutor_user_id IS NOT NULL THEN
            INSERT INTO notifications (user_id, title, content, type, reference_id, reference_table, expires_at)
            VALUES (v_tutor_user_id,
                    'Buổi dạy sắp diễn ra',
                    CONCAT('Bạn có buổi dạy vào lúc ', v_start_time, ' ngày hôm nay.'),
                    'SCHEDULE',
                    v_session_id,
                    'teaching_sessions',
                    DATE_ADD(CONCAT(v_session_date, ' ', v_start_time), INTERVAL 2 HOUR));
        END IF;

        -- Thông báo cho học sinh
        INSERT INTO notifications (user_id, title, content, type, reference_id, reference_table, expires_at)
        SELECT u.user_id,
               'Buổi học sắp diễn ra',
               CONCAT('Bạn có buổi học vào lúc ', v_start_time, ' ngày hôm nay. Hãy chuẩn bị bài đầy đủ nhé!'),
               'SCHEDULE',
               v_session_id,
               'teaching_sessions',
               DATE_ADD(CONCAT(v_session_date, ' ', v_start_time), INTERVAL 2 HOUR)
        FROM enrollments e
                 JOIN students s ON e.student_id = s.student_id
                 JOIN users u ON s.user_id = u.user_id
        WHERE e.class_id = v_class_id;

        -- Thông báo cho phụ huynh
        INSERT INTO notifications (user_id, title, content, type, reference_id, reference_table, expires_at)
        SELECT pu.user_id,
               'Con bạn sắp có buổi học',
               CONCAT('Con bạn ', s.full_name, ' có buổi học vào lúc ', v_start_time, ' ngày hôm nay.'),
               'SCHEDULE',
               v_session_id,
               'teaching_sessions',
               DATE_ADD(CONCAT(v_session_date, ' ', v_start_time), INTERVAL 2 HOUR)
        FROM enrollments e
                 JOIN students s ON e.student_id = s.student_id
                 JOIN parents p ON s.parent_id = p.parent_id
                 JOIN users pu ON p.user_id = pu.user_id
        WHERE e.class_id = v_class_id;

    END LOOP;
    CLOSE cur_sessions;
END;

