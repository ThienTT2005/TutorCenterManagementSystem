create definer = root@localhost view vw_homework_completion as
select `c`.`class_id`                                                                                            AS `class_id`,
       `c`.`class_name`                                                                                          AS `class_name`,
       count(distinct `h`.`homework_id`)                                                                         AS `total_homework`,
       count(distinct `hs`.`submission_id`)                                                                      AS `total_submissions`,
       round(((count(distinct `hs`.`submission_id`) * 100.0) / nullif(count(distinct `h`.`homework_id`), 0)),
             2)                                                                                                  AS `submission_rate`,
       avg(`hs`.`score`)                                                                                         AS `avg_score`
from (((`tcms`.`classes` `c` left join `tcms`.`teaching_sessions` `s`
        on ((`c`.`class_id` = `s`.`class_id`))) left join `tcms`.`homework` `h`
       on ((`s`.`session_id` = `h`.`session_id`))) left join `tcms`.`homework_submissions` `hs`
      on ((`h`.`homework_id` = `hs`.`homework_id`)))
group by `c`.`class_id`, `c`.`class_name`;

