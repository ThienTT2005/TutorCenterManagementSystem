create definer = root@localhost trigger trg_process_absence_request
    after update
    on absence_requests
    for each row
BEGIN
    IF NEW.status = 'APPROVED' AND OLD.status != 'APPROVED' THEN
        UPDATE attendance
        SET status = 'ABSENT_EXCUSED',
            absence_reason = NEW.reason,
            is_valid = FALSE,
            note = CONCAT('Xin nghỉ có phép. Lý do: ', NEW.reason)
        WHERE session_id = NEW.session_id AND student_id = NEW.student_id;

        IF ROW_COUNT() = 0 THEN
            INSERT INTO attendance (session_id, student_id, status, absence_reason, is_valid, note)
            VALUES (NEW.session_id, NEW.student_id, 'ABSENT_EXCUSED', NEW.reason, FALSE,
                    CONCAT('Xin nghỉ có phép. Lý do: ', NEW.reason));
        END IF;

        INSERT INTO notifications (user_id, title, content, type, reference_id, reference_table)
        SELECT t.user_id,
               'Học sinh xin nghỉ học',
               CONCAT('Học sinh đã được phép nghỉ buổi học ngày ', s.session_date, '. Lý do: ', NEW.reason),
               'ATTENDANCE',
               NEW.request_id,
               'absence_requests'
        FROM teaching_sessions s
                 JOIN classes c ON s.class_id = c.class_id
                 JOIN tutors t ON c.tutor_id = t.tutor_id
        WHERE s.session_id = NEW.session_id;
    END IF;
END;

