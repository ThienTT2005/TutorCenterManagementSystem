create
    definer = root@localhost procedure sp_parent_dashboard(IN p_parent_id int)
BEGIN
    SELECT COUNT(DISTINCT s.session_id) AS classes_today
    FROM teaching_sessions s
             JOIN classes c ON s.class_id = c.class_id
             JOIN enrollments e ON c.class_id = e.class_id
             JOIN students st ON e.student_id = st.student_id
    WHERE st.parent_id = p_parent_id
      AND s.session_date = CURDATE();

    SELECT COUNT(DISTINCT h.homework_id) AS homework_pending
    FROM homework h
             JOIN teaching_sessions s ON h.session_id = s.session_id
             JOIN classes c ON s.class_id = c.class_id
             JOIN enrollments e ON c.class_id = e.class_id
             JOIN students st ON e.student_id = st.student_id
             LEFT JOIN homework_submissions hs ON h.homework_id = hs.homework_id AND hs.student_id = st.student_id
    WHERE st.parent_id = p_parent_id
      AND (hs.submission_id IS NULL OR hs.status = 'SUBMITTED' AND hs.graded_at IS NULL)
      AND h.deadline >= CURDATE();

    SELECT COUNT(*) AS new_feedback
    FROM feedback f
             JOIN teaching_sessions s ON f.session_id = s.session_id
             JOIN classes c ON s.class_id = c.class_id
             JOIN enrollments e ON c.class_id = e.class_id
             JOIN students st ON e.student_id = st.student_id
    WHERE st.parent_id = p_parent_id
      AND f.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY);

    SELECT COUNT(*) AS pending_payments
    FROM payments p
             JOIN students st ON p.student_id = st.student_id
    WHERE st.parent_id = p_parent_id
      AND p.status IN ('PENDING', 'PROOF_UPLOADED');
END;

