create definer = root@localhost view vw_feedback_summary as
select `t`.`tutor_id`                                                AS `tutor_id`,
       `t`.`full_name`                                               AS `tutor_name`,
       count(`f`.`feedback_id`)                                      AS `total_feedback`,
       sum((case when (`f`.`is_late` = true) then 1 else 0 end))     AS `late_feedback`,
       sum((case when (`f`.`status` = 'PENDING') then 1 else 0 end)) AS `pending_feedback`,
       avg((case
                when (`f`.`rating` = 'Xuất sắc') then 5
                when (`f`.`rating` = 'Giỏi') then 4
                when (`f`.`rating` = 'Khá') then 3
                when (`f`.`rating` = 'Trung bình') then 2
                when (`f`.`rating` = 'Yếu') then 1 end))             AS `avg_rating_score`
from (((`tcms`.`tutors` `t` left join `tcms`.`classes` `c`
        on ((`t`.`tutor_id` = `c`.`tutor_id`))) left join `tcms`.`teaching_sessions` `s`
       on ((`c`.`class_id` = `s`.`class_id`))) left join `tcms`.`feedback` `f`
      on ((`s`.`session_id` = `f`.`session_id`)))
group by `t`.`tutor_id`, `t`.`full_name`;

