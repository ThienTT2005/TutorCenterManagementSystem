create definer = root@localhost trigger trg_calculate_session_validity
    after update
    on feedback
    for each row
BEGIN
    DECLARE v_attendance_valid BOOLEAN;
    DECLARE v_tuition_fee DECIMAL(10,2);
    DECLARE v_calculated_amount DECIMAL(10,2);

    IF NEW.status = 'APPROVED' AND OLD.status != 'APPROVED' THEN
        SELECT is_valid INTO v_attendance_valid
        FROM attendance
        WHERE session_id = NEW.session_id AND student_id = NEW.student_id;

        SELECT c.tuition_fee_per_session INTO v_tuition_fee
        FROM teaching_sessions s
                 JOIN classes c ON s.class_id = c.class_id
        WHERE s.session_id = NEW.session_id;

        IF v_attendance_valid = TRUE THEN
            SET v_calculated_amount = v_tuition_fee * (100 - NEW.penalty_rate) / 100;
        ELSE
            SET v_calculated_amount = 0;
        END IF;

        INSERT INTO session_validity_log (session_id, student_id, attendance_valid,
                                          feedback_status, feedback_penalty,
                                          feedback_submitted_at, calculated_amount)
        VALUES (NEW.session_id, NEW.student_id, v_attendance_valid,
                IF(NEW.is_late = TRUE, 'LATE', 'ON_TIME'),
                NEW.penalty_rate, NEW.submitted_at, v_calculated_amount);
    END IF;
END;

