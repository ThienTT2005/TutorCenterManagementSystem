create definer = root@localhost trigger trg_check_feedback_late
    before insert
    on feedback
    for each row
BEGIN
    DECLARE v_session_datetime DATETIME;
    DECLARE v_feedback_deadline DATETIME;

    SELECT CONCAT(s.session_date, ' ', s.end_time) INTO v_session_datetime
    FROM teaching_sessions s
    WHERE s.session_id = NEW.session_id;

    SET v_feedback_deadline = DATE_ADD(v_session_datetime, INTERVAL 4 HOUR);

    IF NEW.submitted_at > v_feedback_deadline THEN
        SET NEW.is_late = TRUE;
        SET NEW.penalty_rate = 25;
    ELSE
        SET NEW.is_late = FALSE;
        SET NEW.penalty_rate = 0;
    END IF;
END;

